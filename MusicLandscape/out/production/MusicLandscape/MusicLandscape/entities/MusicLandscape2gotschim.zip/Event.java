package MusicLandscape.entities;

import MusicLandscape.Date;
import MusicLandscape.Venue;

import java.util.Objects;

public class Event {

    private Artist artist = new Artist();

    private int attendees;

    private Date date = null;

    private String description = "";

    private Venue venue;

    public Event() {
    }


    public Artist getArtist() {
        return artist;
    }

    public void setArtist(Artist artist) {
        if (artist == null) {
            return;
        }
        this.artist = artist;
    }

    public int getAttendees() {
        return attendees;
    }

    public void setAttendees(int attendees) {
        if (attendees >= 0) {
            this.attendees = attendees;
        }
    }

    public Date getDate() {
        if (this.date != null) {
            return new Date();
        }
        return this.date;
    }

    public void setDate(Date date) {
        if(date != null) {
            date = new Date();
        }
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = Objects.requireNonNullElse(description, "");
    }

    public Venue getVenue() {
        return venue;
    }

    public void setVenue(Venue venue) {
        this.venue = venue;
    }
}
