package MusicLandscape.entities;

import org.testng.util.Strings;
public class Track {
    private String title;
    private int duration;
    private Artist writer = new Artist();
    private Artist performer = new Artist();
    private int year;

    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        if (year < 1900 || year > 2999) {
            return;
        }
        this.year = year;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        if (duration < 0) {
            return;
        }
        this.duration = duration;
    }

    public String getTitle() {
        if(Strings.isNullOrEmpty(this.title)) {
            return "unknown title";
        }
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Artist getWriter() {
        return writer;
    }

    public void setWriter(Artist writer) {
        if(writer == null) {
            return;
        }
        this.writer = writer;
    }

    public Artist getPerformer() {
        return performer;
    }

    public void setPerformer(Artist performer) {
        if (performer == null) {
            return;
        }

        this.performer = performer;
    }

    public boolean writerIsKnown() {
        if (this.writer==null) {
            return false;
        }

        return !Strings.isNullOrEmpty(this.writer.getName());
    }

    public String getString() {
        String writer = this.writer == null ? "" : this.writer.getName();
        if (Strings.isNullOrEmpty(writer)) {
            writer = "unknown";
        }

        String performer = this.performer == null ? "" : this.performer.getName();
        if (Strings.isNullOrEmpty(performer)) {
            performer = "unknown";
        }

        String title = this.title;
        if (Strings.isNullOrEmpty(title)) {
            title = "unknown";
        }

        return String.format("%10.10s by %10.10s performed by %10.10s (%02d:%02d)", title, writer, performer, duration / 60, (duration % 60));
    }
}
